@echo off
cd /d "%~dp0"
call mvn clean package
if errorlevel 1 exit /b 1
if not exist dist mkdir dist
copy /Y target\biblioteca-1.0.0.jar dist\biblioteca.jar
