package cl.eft.biblioteca;
import cl.eft.biblioteca.model.*;
import cl.eft.biblioteca.util.*;
import cl.eft.biblioteca.config.*;
public final class PruebasBasicas  {
    public static void main(String[] args) {
        String h=PasswordUtil.hash("Prueba123!".toCharArray());
        check(PasswordUtil.verify("Prueba123!".toCharArray(),h),"Hash válido");
        check(!PasswordUtil.verify("incorrecta".toCharArray(),h),"Rechazo de contraseña");
        check(!PasswordUtil.verify("algo".toCharArray(),"malformado"),"Hash inválido");
        Usuario admin=Usuario.crear(1,"Admin","A","a@local.test",h,"BIBLIOTECARIO"),student=Usuario.crear(2,"Ana","B","b@local.test",h,"ESTUDIANTE");
        check(admin.puedeAdministrar()&&!student.puedeAdministrar(),"Permisos polimórficos");
        check(admin instanceof Persona&&student instanceof Persona,"Herencia");
        check(DatabaseConnection.getInstance()==DatabaseConnection.getInstance(),"Singleton");
        check(DatabaseConnection.getInstance().diasPrestamo()==7,"Plazo predeterminado");
        System.out.println("7 comprobaciones correctas");
    }
    static void check(boolean ok,String msg) {
        if(!ok)throw new AssertionError(msg);
    }
}
