package cl.eft.biblioteca;
import cl.eft.biblioteca.config.*;
import cl.eft.biblioteca.service.*;
import cl.eft.biblioteca.model.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
/** Prueba real MySQL: crea datos temporales y los elimina al finalizar. */
public final class PruebaConcurrencia  {
    public static void main(String[] args)throws Exception {
        var db=DatabaseConnection.getInstance();
        var service=new BibliotecaService();
        Usuario admin=Usuario.crear(0,"Test","TEST","test@test.local","","BIBLIOTECARIO");
        int[] ids=new int[3];
        try {
            db.transaccion(c-> {
                String key="TEST"+java.util.UUID.randomUUID().toString().replace("-", "").substring(0,8);try(var s=c.prepareStatement("INSERT INTO categorias(nombre) VALUES(?)",1)) {
                    s.setString(1,key);s.executeUpdate();try(var r=s.getGeneratedKeys()) {
                        r.next();ids[0]=r.getInt(1);
                    }
                }
                try(var s=c.prepareStatement("INSERT INTO estudiantes(nombre,rut,curso,correo) VALUES(?,?,?,?)",1)) {
                    s.setString(1,key);s.setString(2,key);s.setString(3,"TEST");s.setString(4,key+"@test.local");s.executeUpdate();try(var r=s.getGeneratedKeys()) {
                        r.next();ids[1]=r.getInt(1);
                    }
                }
                try(var s=c.prepareStatement("INSERT INTO libros(titulo,autor,isbn,editorial,stock,id_categoria) VALUES(?,?,?,?,1,?)",1)) {
                    for(int i=1;i<=4;i++)s.setString(i,key);s.setInt(5,ids[0]);s.executeUpdate();try(var r=s.getGeneratedKeys()) {
                        r.next();ids[2]=r.getInt(1);
                    }
                }
                return null;
            }
            );
            ExecutorService pool=Executors.newFixedThreadPool(8);
            CountDownLatch start=new CountDownLatch(1);
            AtomicInteger ok=new AtomicInteger(),no=new AtomicInteger(),loan=new AtomicInteger();
            java.util.List<Future<?>> tasks=new java.util.ArrayList<>();
            try {
                for(int i=0;i<8;i++)tasks.add(pool.submit(()-> {
                    try {
                        start.await();loan.set(service.prestar(admin,ids[1],ids[2]));ok.incrementAndGet();
                    }
                    catch(java.sql.SQLException ex) {
                        if(!ex.getMessage().contains("sin stock"))throw new RuntimeException(ex);no.incrementAndGet();
                    }
                    catch(InterruptedException ex) {
                        Thread.currentThread().interrupt();throw new RuntimeException(ex);
                    }
                }
                ));
                start.countDown();
                for(var f:tasks)f.get(30,TimeUnit.SECONDS);
            }
            finally {
                pool.shutdownNow();
            }
            if(ok.get()!=1||no.get()!=7)throw new AssertionError("Se esperaba 1 éxito y 7 rechazos");
            int stock=db.ejecutar(c-> {
                try(var s=c.prepareStatement("SELECT stock FROM libros WHERE id=?")) {
                    s.setInt(1,ids[2]);try(var r=s.executeQuery()) {
                        r.next();return r.getInt(1);
                    }
                }
            }
            );
            if(stock!=0)throw new AssertionError("Stock inconsistente");
            service.devolver(admin,loan.get());
            try {
                service.devolver(admin,loan.get());
                throw new AssertionError("Aceptó doble devolución");
            }
            catch(java.sql.SQLException expected) {
                if(!expected.getMessage().contains("ya fue devuelto"))throw expected;
            }
            try {
                service.prestar(admin,-1,ids[2]);
                throw new AssertionError("Aceptó ID inválido");
            }
            catch(IllegalArgumentException expected) {
            }
            System.out.println("Concurrencia y doble devolución correctas");
        }
        finally {
            db.transaccion(c-> {
                for(String sql:new String[] {
                    "DELETE FROM prestamos WHERE id_libro=?","DELETE FROM libros WHERE id=?","DELETE FROM estudiantes WHERE id=?","DELETE FROM categorias WHERE id=?"
                }
                )try(var s=c.prepareStatement(sql)) {
                    s.setInt(1,sql.contains("prestamos")||sql.contains("libros")?ids[2]:sql.contains("estudiantes")?ids[1]:ids[0]);s.executeUpdate();
                }
                return null;
            }
            );
            db.close();
        }
    }
}
