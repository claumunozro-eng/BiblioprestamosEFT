package cl.eft.biblioteca.model;
public final class Categoria implements Entidad  {
    private int id;
    private final String nombre;
    public Categoria(int id,String nombre) {
        this.id=id;
        this.nombre=nombre;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id=id;
    }
    public String getNombre() {
        return nombre;
    }
}
