package cl.eft.biblioteca.dao;
import cl.eft.biblioteca.model.*;
import java.sql.*;
public final class CategoriaDAO extends JdbcDAO<Categoria> {
    public CategoriaDAO() {
        super("categorias","nombre");
    }
    protected Categoria map(ResultSet r)throws SQLException {
        return new Categoria(r.getInt("id"),r.getString("nombre"));
    }
    protected Object[] values(Categoria e) {
        return new Object[] {
            e.getNombre()
        }
        ;
    }
}
