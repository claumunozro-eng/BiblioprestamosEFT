package cl.eft.biblioteca.dao;
import cl.eft.biblioteca.model.*;
import java.sql.*;
public final class PrestamoDAO extends JdbcDAO<Prestamo> {
    public PrestamoDAO() {
        super("prestamos","id_estudiante,id_libro,fecha_prestamo,fecha_devolucion,devuelto,fecha_devolucion_real,dias_atraso");
    }
    protected Prestamo map(ResultSet r)throws SQLException {
        return new Prestamo(r.getInt("id"),r.getInt("id_estudiante"),r.getInt("id_libro"),r.getDate("fecha_prestamo").toLocalDate(),r.getDate("fecha_devolucion").toLocalDate(),r.getBoolean("devuelto"),r.getDate("fecha_devolucion_real")==null?null:r.getDate("fecha_devolucion_real").toLocalDate(),r.getInt("dias_atraso"));
    }
    protected Object[] values(Prestamo e) {
        return new Object[] {
            e.getIdEstudiante(),e.getIdLibro(),e.getFechaPrestamo(),e.getFechaDevolucion(),e.getDevuelto(),e.getFechaDevolucionReal(),e.getDiasAtraso()
        }
        ;
    }
}
