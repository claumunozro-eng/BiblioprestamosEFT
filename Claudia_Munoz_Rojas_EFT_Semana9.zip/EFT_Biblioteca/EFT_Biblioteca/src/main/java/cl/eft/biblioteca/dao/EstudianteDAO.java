package cl.eft.biblioteca.dao;
import cl.eft.biblioteca.model.*;
import java.sql.*;
public final class EstudianteDAO extends JdbcDAO<Estudiante> {
    public EstudianteDAO() {
        super("estudiantes","nombre,rut,curso,correo");
    }
    protected Estudiante map(ResultSet r)throws SQLException {
        return new Estudiante(r.getInt("id"),r.getString("nombre"),r.getString("rut"),r.getString("curso"),r.getString("correo"));
    }
    protected Object[] values(Estudiante e) {
        return new Object[] {
            e.getNombre(),e.getRut(),e.getCurso(),e.getCorreo()
        }
        ;
    }
}
