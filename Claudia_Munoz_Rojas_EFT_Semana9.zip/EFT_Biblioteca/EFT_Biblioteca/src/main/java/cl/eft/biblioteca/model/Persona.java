package cl.eft.biblioteca.model;
public abstract class Persona implements Entidad  {
    private int id;
    private String nombre,rut,correo;
    protected Persona(int id,String nombre,String rut,String correo) {
        this.id=id;
        this.nombre=nombre;
        this.rut=rut;
        this.correo=correo;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id=id;
    }
    public String getNombre() {
        return nombre;
    }
    public String getRut() {
        return rut;
    }
    public String getCorreo() {
        return correo;
    }
    public abstract String descripcion();
}
