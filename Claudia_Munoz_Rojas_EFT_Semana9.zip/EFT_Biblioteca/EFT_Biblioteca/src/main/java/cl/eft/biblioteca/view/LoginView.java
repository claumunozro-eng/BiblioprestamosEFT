package cl.eft.biblioteca.view;
import javax.swing.*;
import java.awt.*;
public final class LoginView extends JFrame  {
    public final JTextField correo=new JTextField(25);
    public final JPasswordField password=new JPasswordField(25);
    public final JButton entrar=new JButton("Ingresar");
    public final JLabel estado=new JLabel("Ingresa tu correo y contraseña");
    public LoginView() {
        super("Biblioteca escolar · Acceso");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        JPanel p=new JPanel(new GridLayout(0,1,8,8));
        p.setBorder(BorderFactory.createEmptyBorder(24,30,24,30));
        p.add(new JLabel("Biblioteca escolar"));
        p.add(new JLabel("Correo"));
        p.add(correo);
        p.add(new JLabel("Contraseña"));
        p.add(password);
        p.add(entrar);
        p.add(estado);
        setContentPane(p);
        getRootPane().setDefaultButton(entrar);
        pack();
        setLocationRelativeTo(null);
    }
}
