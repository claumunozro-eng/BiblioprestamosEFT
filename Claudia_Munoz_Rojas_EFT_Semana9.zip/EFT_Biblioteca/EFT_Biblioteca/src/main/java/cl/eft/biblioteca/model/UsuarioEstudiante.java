package cl.eft.biblioteca.model;
public final class UsuarioEstudiante extends Usuario  {
    public UsuarioEstudiante(int id,String nombre,String rut,String correo,String password) {
        super(id,nombre,rut,correo,password);
    }
    public boolean puedeAdministrar() {
        return false;
    }
    public String getRol() {
        return "ESTUDIANTE";
    }
}
