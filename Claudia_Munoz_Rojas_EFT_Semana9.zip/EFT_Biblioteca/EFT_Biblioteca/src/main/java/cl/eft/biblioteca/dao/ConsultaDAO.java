package cl.eft.biblioteca.dao;
import cl.eft.biblioteca.config.DatabaseConnection;
import java.sql.*;
import java.util.*;
public final class ConsultaDAO  {
    public record Tabla(String[] columnas,List<Object[]> filas) {
    }
    public Tabla consulta(String sql,Object...params)throws SQLException {
        return DatabaseConnection.getInstance().ejecutar(c-> {
            try(PreparedStatement s=c.prepareStatement(sql)) {
                for(int i=0;i<params.length;i++)s.setObject(i+1,params[i]);try(ResultSet r=s.executeQuery()) {
                    int n=r.getMetaData().getColumnCount();String[] cols=new String[n];for(int i=0;i<n;i++)cols[i]=r.getMetaData().getColumnLabel(i+1);List<Object[]> rows=new ArrayList<>();while(r.next()) {
                        Object[] row=new Object[n];for(int i=0;i<n;i++)row[i]=r.getObject(i+1);rows.add(row);
                    }
                    return new Tabla(cols,rows);
                }
            }
        }
        );
    }
    public UsuarioDatos usuarioPorCorreo(String correo)throws SQLException {
        return DatabaseConnection.getInstance().ejecutar(c-> {
            try(PreparedStatement s=c.prepareStatement("SELECT * FROM usuarios WHERE correo=?")) {
                s.setString(1,correo);try(ResultSet r=s.executeQuery()) {
                    return r.next()?new UsuarioDatos(r.getInt("id"),r.getString("nombre"),r.getString("rut"),r.getString("correo"),r.getString("contraseña"),r.getString("rol").toUpperCase(java.util.Locale.ROOT)):null;
                }
            }
        }
        );
    }
    public record UsuarioDatos(int id,String nombre,String rut,String correo,String password,String rol) {
    }
    public int estudiantePorRut(String rut)throws SQLException {
        return DatabaseConnection.getInstance().ejecutar(c-> {
            try(PreparedStatement s=c.prepareStatement("SELECT id FROM estudiantes WHERE rut=?")) {
                s.setString(1,rut);try(ResultSet r=s.executeQuery()) {
                    if(!r.next())throw new SQLException("El usuario no está vinculado a un estudiante. Contacta al bibliotecario.");return r.getInt(1);
                }
            }
        }
        );
    }
}
