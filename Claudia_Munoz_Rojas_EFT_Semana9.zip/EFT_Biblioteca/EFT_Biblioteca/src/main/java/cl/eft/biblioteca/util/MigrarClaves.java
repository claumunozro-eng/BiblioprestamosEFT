package cl.eft.biblioteca.util;
import cl.eft.biblioteca.config.DatabaseConnection;
import java.util.*;
/** Conversión explícita de las claves de muestra oficiales a PBKDF2. */
public final class MigrarClaves  {
    public static void main(String[] args)throws Exception {
        var db=DatabaseConnection.getInstance();
        try {
            int count=db.transaccion(c-> {
                Map<Integer,String> rows=new LinkedHashMap<>();try(var s=c.prepareStatement("SELECT id,`contraseña` FROM usuarios");var r=s.executeQuery()) {
                    while(r.next())rows.put(r.getInt(1),r.getString(2));
                }
                int n=0;try(var s=c.prepareStatement("UPDATE usuarios SET `contraseña`=? WHERE id=?")) {
                    for(var row:rows.entrySet()) {
                        String password=row.getValue();if(password==null||password.isBlank())throw new IllegalArgumentException("Cuenta sin clave: "+row.getKey());if(password.startsWith("pbkdf2$"))continue;char[] chars=password.toCharArray();try {
                            s.setString(1,PasswordUtil.hash(chars));s.setInt(2,row.getKey());s.executeUpdate();n++;
                        }
                        finally {
                            Arrays.fill(chars,'\0');
                        }
                    }
                }
                return n;
            }
            );
            System.out.println("Contraseñas convertidas: "+count);
        }
        finally {
            db.close();
        }
    }
}
