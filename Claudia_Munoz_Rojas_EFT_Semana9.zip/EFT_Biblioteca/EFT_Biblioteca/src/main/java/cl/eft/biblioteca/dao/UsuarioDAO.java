package cl.eft.biblioteca.dao;
import cl.eft.biblioteca.model.*;
import java.sql.*;
public final class UsuarioDAO extends JdbcDAO<Usuario> {
    public UsuarioDAO() {
        super("usuarios","nombre,rut,correo,`contraseña`,rol");
    }
    protected Usuario map(ResultSet r)throws SQLException {
        return Usuario.crear(r.getInt("id"),r.getString("nombre"),r.getString("rut"),r.getString("correo"),r.getString("contraseña"),r.getString("rol").toUpperCase(java.util.Locale.ROOT));
    }
    protected Object[] values(Usuario e) {
        return new Object[] {
            e.getNombre(),e.getRut(),e.getCorreo(),e.getPassword(),e.getRol().toLowerCase(java.util.Locale.ROOT)
        }
        ;
    }
}
