package cl.eft.biblioteca;
import javax.swing.*;
import cl.eft.biblioteca.controller.BibliotecaController;
import cl.eft.biblioteca.config.DatabaseConnection;
public final class App  {
    public static void main(String[] args) {
        Runtime.getRuntime().addShutdownHook(new Thread(()-> {
            try {
                DatabaseConnection.getInstance().close();
            }
            catch(Exception ignored) {
            }
        }
        ));
        SwingUtilities.invokeLater(()-> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());new BibliotecaController().iniciar();
            }
            catch(Exception e) {
                JOptionPane.showMessageDialog(null,e.getMessage(),"Error al iniciar",JOptionPane.ERROR_MESSAGE);
            }
        }
        );
    }
}
