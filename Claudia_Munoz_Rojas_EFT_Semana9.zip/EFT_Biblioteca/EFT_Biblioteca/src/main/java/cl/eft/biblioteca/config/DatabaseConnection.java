package cl.eft.biblioteca.config;
import java.sql.*;
import java.util.Properties;
import java.nio.file.*;
import java.io.*;
/** Una conexión compartida. Toda operación se serializa en este monitor. */
public final class DatabaseConnection implements AutoCloseable  {
    private static final DatabaseConnection INSTANCE=new DatabaseConnection();
    private final Properties config=new Properties();
    private Connection connection;
    private DatabaseConnection() {
        try {
            Path p=Path.of(System.getProperty("biblioteca.config","config/database.properties"));
            if(Files.exists(p))try(InputStream in=Files.newInputStream(p)) {
                config.load(in);
            }
        }
        catch(IOException e) {
            throw new IllegalStateException("No se pudo leer configuración",e);
        }
    }
    public static DatabaseConnection getInstance() {
        return INSTANCE;
    }
    public int diasPrestamo() {
        int n=Integer.parseInt(config.getProperty("prestamo.dias","7"));
        if(n<1||n>365)throw new IllegalArgumentException("Plazo inválido");
        return n;
    }
    private String value(String env,String key,String fallback) {
        String v=System.getenv(env);
        return v==null?config.getProperty(key,fallback):v;
    }
    private Connection getConnection()throws SQLException {
        if(connection==null||connection.isClosed()||!connection.isValid(2)) {
            connection=DriverManager.getConnection(value("BIBLIOTECA_DB_URL","db.url","jdbc:mysql://localhost:3306/biblioteca"),value("BIBLIOTECA_DB_USER","db.user","biblioteca_app"),value("BIBLIOTECA_DB_PASSWORD","db.password",""));
        }
        return connection;
    }
    @FunctionalInterface public interface Trabajo<T> {
        T ejecutar(Connection c)throws SQLException;
    }
    public synchronized <T>T ejecutar(Trabajo<T> trabajo)throws SQLException {
        return trabajo.ejecutar(getConnection());
    }
    public synchronized <T>T transaccion(Trabajo<T> trabajo)throws SQLException {
        Connection c=getConnection();
        boolean old=c.getAutoCommit();
        c.setAutoCommit(false);
        try {
            T r=trabajo.ejecutar(c);
            c.commit();
            return r;
        }
        catch(SQLException|RuntimeException ex) {
            try {
                c.rollback();
            }
            catch(SQLException rollback) {
                ex.addSuppressed(rollback);
            }
            throw ex;
        }
        finally {
            c.setAutoCommit(old);
        }
    }
    public synchronized void close()throws SQLException {
        if(connection!=null)connection.close();
    }
}
