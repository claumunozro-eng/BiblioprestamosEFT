package cl.eft.biblioteca.dao;
import cl.eft.biblioteca.model.Entidad;
import cl.eft.biblioteca.config.DatabaseConnection;
import java.sql.*;
import java.util.*;
public abstract class JdbcDAO<T extends Entidad> implements CrudDAO<T> {
    protected final DatabaseConnection db=DatabaseConnection.getInstance();
    private final String tabla,columnas;
    protected JdbcDAO(String tabla,String columnas) {
        this.tabla=tabla;
        this.columnas=columnas;
    }
    protected abstract T map(ResultSet r)throws SQLException;
    protected abstract Object[] values(T e);
    public List<T> listar()throws SQLException {
        return db.ejecutar(c-> {
            List<T> out=new ArrayList<>();try(PreparedStatement s=c.prepareStatement("SELECT * FROM "+tabla+" ORDER BY id");ResultSet r=s.executeQuery()) {
                while(r.next())out.add(map(r));
            }
            return out;
        }
        );
    }
    public T buscar(int id)throws SQLException {
        return db.ejecutar(c-> {
            try(PreparedStatement s=c.prepareStatement("SELECT * FROM "+tabla+" WHERE id=?")) {
                s.setInt(1,id);try(ResultSet r=s.executeQuery()) {
                    return r.next()?map(r):null;
                }
            }
        }
        );
    }
    public void guardar(T e)throws SQLException {
        db.ejecutar(c-> {
            guardar(c,e);return null;
        }
        );
    }
    public void guardar(Connection c,T e)throws SQLException {
        String[] cols=columnas.split(",");
        String sql=e.getId()==0?"INSERT INTO "+tabla+" ("+columnas+") VALUES ("+String.join(",",Collections.nCopies(cols.length,"?"))+")":"UPDATE "+tabla+" SET "+String.join(",",Arrays.stream(cols).map(x->x+"=?").toList())+" WHERE id=?";
        try(PreparedStatement s=c.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)) {
            Object[] v=values(e);
            for(int i=0;i<v.length;i++)s.setObject(i+1,v[i]);
            if(e.getId()!=0)s.setInt(v.length+1,e.getId());
            if(s.executeUpdate()!=1)throw new SQLException("Registro inexistente");
            if(e.getId()==0)try(ResultSet r=s.getGeneratedKeys()) {
                if(r.next())e.setId(r.getInt(1));
            }
        }
    }
    public void eliminar(int id)throws SQLException {
        db.ejecutar(c-> {
            try(PreparedStatement s=c.prepareStatement("DELETE FROM "+tabla+" WHERE id=?")) {
                s.setInt(1,id);if(s.executeUpdate()!=1)throw new SQLException("Registro inexistente");
            }
            return null;
        }
        );
    }
}
