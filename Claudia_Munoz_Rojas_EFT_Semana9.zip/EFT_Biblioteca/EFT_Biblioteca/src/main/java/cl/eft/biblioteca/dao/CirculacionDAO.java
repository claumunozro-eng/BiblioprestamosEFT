package cl.eft.biblioteca.dao;
import java.sql.*;
import java.time.*;
import java.time.temporal.ChronoUnit;
/** SQL de circulación. El servicio proporciona una transacción activa. */
public final class CirculacionDAO  {
    public int prestar(Connection c,int estudiante,int libro,int dias)throws SQLException {
        try(PreparedStatement s=c.prepareStatement("SELECT id FROM estudiantes WHERE id=?")) {
            s.setInt(1,estudiante);
            try(ResultSet r=s.executeQuery()) {
                if(!r.next())throw new SQLException("Estudiante inexistente");
            }
        }
        try(PreparedStatement s=c.prepareStatement("UPDATE libros SET stock=stock-1 WHERE id=? AND stock>0")) {
            s.setInt(1,libro);
            if(s.executeUpdate()!=1)throw new SQLException("Libro inexistente o sin stock");
        }
        try(PreparedStatement s=c.prepareStatement("INSERT INTO prestamos(id_estudiante,id_libro,fecha_prestamo,fecha_devolucion,devuelto,dias_atraso) VALUES(?,?,?,?,false,0)",Statement.RETURN_GENERATED_KEYS)) {
            s.setInt(1,estudiante);
            s.setInt(2,libro);
            s.setObject(3,LocalDate.now());
            s.setObject(4,LocalDate.now().plusDays(dias));
            s.executeUpdate();
            try(ResultSet r=s.getGeneratedKeys()) {
                if(r.next())return r.getInt(1);
                throw new SQLException("Sin ID de préstamo");
            }
        }
    }
    public int devolver(Connection c,int prestamo,Integer estudiante)throws SQLException {
        int libro,owner;
        LocalDate vence;
        try(PreparedStatement s=c.prepareStatement("SELECT id_libro,id_estudiante,fecha_devolucion,devuelto FROM prestamos WHERE id=? FOR UPDATE")) {
            s.setInt(1,prestamo);
            try(ResultSet r=s.executeQuery()) {
                if(!r.next())throw new SQLException("Préstamo inexistente");
                if(r.getBoolean("devuelto"))throw new SQLException("El préstamo ya fue devuelto");
                libro=r.getInt("id_libro");
                owner=r.getInt("id_estudiante");
                vence=r.getDate("fecha_devolucion").toLocalDate();
            }
        }
        if(estudiante!=null&&owner!=estudiante)throw new SQLException("Solo puedes devolver tus propios préstamos");
        int atraso=(int)Math.max(0,ChronoUnit.DAYS.between(vence,LocalDate.now()));
        try(PreparedStatement s=c.prepareStatement("UPDATE prestamos SET devuelto=true,fecha_devolucion_real=?,dias_atraso=? WHERE id=?")) {
            s.setObject(1,LocalDate.now());
            s.setInt(2,atraso);
            s.setInt(3,prestamo);
            s.executeUpdate();
        }
        try(PreparedStatement s=c.prepareStatement("UPDATE libros SET stock=stock+1 WHERE id=?")) {
            s.setInt(1,libro);
            if(s.executeUpdate()!=1)throw new SQLException("Libro inexistente");
        }
        return atraso;
    }
}
