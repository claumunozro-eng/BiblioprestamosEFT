package cl.eft.biblioteca.model;
public interface Entidad  {
    int getId();
    void setId(int id);
}
