package cl.eft.biblioteca.model;
public final class Bibliotecario extends Usuario  {
    public Bibliotecario(int id,String nombre,String rut,String correo,String password) {
        super(id,nombre,rut,correo,password);
    }
    public boolean puedeAdministrar() {
        return true;
    }
    public String getRol() {
        return "BIBLIOTECARIO";
    }
}
