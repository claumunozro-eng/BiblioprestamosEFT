package cl.eft.biblioteca.model;
public final class Prestamo implements Entidad  {
    private int id;
    private final int idEstudiante;
    private final int idLibro;
    private final java.time.LocalDate fechaPrestamo;
    private final java.time.LocalDate fechaDevolucion;
    private final boolean devuelto;
    private final java.time.LocalDate fechaDevolucionReal;
    private final int diasAtraso;
    public Prestamo(int id,int idEstudiante,int idLibro,java.time.LocalDate fechaPrestamo,java.time.LocalDate fechaDevolucion,boolean devuelto,java.time.LocalDate fechaDevolucionReal,int diasAtraso) {
        this.id=id;
        this.idEstudiante=idEstudiante;
        this.idLibro=idLibro;
        this.fechaPrestamo=fechaPrestamo;
        this.fechaDevolucion=fechaDevolucion;
        this.devuelto=devuelto;
        this.fechaDevolucionReal=fechaDevolucionReal;
        this.diasAtraso=diasAtraso;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id=id;
    }
    public int getIdEstudiante() {
        return idEstudiante;
    }
    public int getIdLibro() {
        return idLibro;
    }
    public java.time.LocalDate getFechaPrestamo() {
        return fechaPrestamo;
    }
    public java.time.LocalDate getFechaDevolucion() {
        return fechaDevolucion;
    }
    public boolean getDevuelto() {
        return devuelto;
    }
    public java.time.LocalDate getFechaDevolucionReal() {
        return fechaDevolucionReal;
    }
    public int getDiasAtraso() {
        return diasAtraso;
    }
}
