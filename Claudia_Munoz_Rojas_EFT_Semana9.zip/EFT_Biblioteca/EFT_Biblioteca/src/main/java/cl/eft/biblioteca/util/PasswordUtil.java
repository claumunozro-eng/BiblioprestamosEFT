package cl.eft.biblioteca.util;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.*;
import java.util.*;
public final class PasswordUtil  {
    private PasswordUtil() {
    }
    private static final int ITERATIONS=210000;
    private static byte[] derive(char[] password,byte[] salt,int n)throws GeneralSecurityException {
        PBEKeySpec spec=new PBEKeySpec(password,salt,n,256);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        }
        finally {
            spec.clearPassword();
        }
    }
    public static String hash(char[] password) {
        try {
            byte[] salt=new byte[16];
            new SecureRandom().nextBytes(salt);
            return "pbkdf2$"+ITERATIONS+"$"+Base64.getEncoder().encodeToString(salt)+"$"+Base64.getEncoder().encodeToString(derive(password,salt,ITERATIONS));
        }
        catch(GeneralSecurityException e) {
            throw new IllegalStateException(e);
        }
    }
    public static boolean verify(char[] password,String stored) {
        try {
            String[] p=stored.split("\\$");
            if(p.length!=4||!p[0].equals("pbkdf2"))return false;
            int n=Integer.parseInt(p[1]);
            if(n<10000||n>1000000)return false;
            return MessageDigest.isEqual(Base64.getDecoder().decode(p[3]),derive(password,Base64.getDecoder().decode(p[2]),n));
        }
        catch(Exception e) {
            return false;
        }
    }
}
