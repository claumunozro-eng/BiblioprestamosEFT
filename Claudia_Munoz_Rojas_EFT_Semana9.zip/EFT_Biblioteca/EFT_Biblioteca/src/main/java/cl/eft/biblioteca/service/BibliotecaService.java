package cl.eft.biblioteca.service;
import cl.eft.biblioteca.model.*;
import cl.eft.biblioteca.dao.*;
import cl.eft.biblioteca.config.*;
import cl.eft.biblioteca.util.*;
import java.sql.*;
import java.util.*;
public final class BibliotecaService  {
    private final DatabaseConnection db=DatabaseConnection.getInstance();
    private final ConsultaDAO consultas=new ConsultaDAO();
    private final CirculacionDAO circulacion=new CirculacionDAO();
    public Usuario login(String correo,char[] password)throws SQLException {
        try {
            var u=consultas.usuarioPorCorreo(correo.trim());
            if(u==null||!PasswordUtil.verify(password,u.password()))throw new SQLException("Correo o contraseña incorrectos");
            return Usuario.crear(u.id(),u.nombre(),u.rut(),u.correo(),u.password(),u.rol().toUpperCase(java.util.Locale.ROOT));
        }
        finally {
            Arrays.fill(password,'\0');
        }
    }
    private void admin(Usuario u) {
        if(u==null||!u.puedeAdministrar())throw new SecurityException("Requiere rol bibliotecario");
    }
    public int estudianteActual(Usuario u)throws SQLException {
        return consultas.estudiantePorRut(u.getRut());
    }
    public synchronized int prestar(Usuario u,int estudiante,int libro)throws SQLException {
        if(u==null)throw new SecurityException("Inicia sesión");
        int target=u.puedeAdministrar()?estudiante:estudianteActual(u);
        if(target<1||libro<1)throw new IllegalArgumentException("Selecciona estudiante y libro válidos");
        return db.transaccion(c->circulacion.prestar(c,target,libro,db.diasPrestamo()));
    }
    public synchronized int devolver(Usuario u,int id)throws SQLException {
        if(u==null)throw new SecurityException("Inicia sesión");
        Integer owner=u.puedeAdministrar()?null:estudianteActual(u);
        return db.transaccion(c->circulacion.devolver(c,id,owner));
    }
    public ConsultaDAO.Tabla catalogo()throws SQLException {
        return consultas.consulta("SELECT l.id,l.titulo,l.autor,l.isbn,l.editorial,l.stock,c.nombre AS categoria FROM libros l JOIN categorias c ON c.id=l.id_categoria ORDER BY l.titulo");
    }
    public ConsultaDAO.Tabla prestamos(Usuario u)throws SQLException {
        String sql="SELECT p.id,e.nombre AS estudiante,l.titulo,p.fecha_prestamo,p.fecha_devolucion AS vencimiento,p.devuelto,p.fecha_devolucion_real,p.dias_atraso,CASE WHEN p.devuelto=false THEN GREATEST(DATEDIFF(CURDATE(),p.fecha_devolucion),0) ELSE p.dias_atraso END AS atraso_actual FROM prestamos p JOIN estudiantes e ON e.id=p.id_estudiante JOIN libros l ON l.id=p.id_libro";
        return u.puedeAdministrar()?consultas.consulta(sql+" ORDER BY p.id DESC"):consultas.consulta(sql+" WHERE p.id_estudiante=? ORDER BY p.id DESC",estudianteActual(u));
    }
    public ConsultaDAO.Tabla reporte(Usuario u,String tipo,int estudiante)throws SQLException {
        if(tipo.equals("Historial")) {
            int target=u.puedeAdministrar()?estudiante:estudianteActual(u);
            return consultas.consulta("SELECT p.id,l.titulo,p.fecha_prestamo,p.fecha_devolucion AS vencimiento,p.devuelto,p.fecha_devolucion_real,p.dias_atraso FROM prestamos p JOIN libros l ON l.id=p.id_libro WHERE p.id_estudiante=? ORDER BY p.id DESC",target);
        }
        admin(u);
        if(tipo.equals("Más prestados"))return consultas.consulta("SELECT l.id,l.titulo,COUNT(p.id) AS cantidad FROM libros l LEFT JOIN prestamos p ON p.id_libro=l.id GROUP BY l.id,l.titulo ORDER BY cantidad DESC,l.titulo");
        return consultas.consulta("SELECT p.id,e.nombre AS estudiante,l.titulo,p.fecha_devolucion AS vencimiento,GREATEST(DATEDIFF(CURDATE(),p.fecha_devolucion),0) AS dias_atraso FROM prestamos p JOIN estudiantes e ON e.id=p.id_estudiante JOIN libros l ON l.id=p.id_libro WHERE p.devuelto=false ORDER BY p.fecha_devolucion");
    }
    public List<? extends Entidad> listar(Usuario u,String tipo)throws SQLException {
        admin(u);
        return dao(tipo).listar();
    }
    private JdbcDAO<? extends Entidad> dao(String tipo) {
        return switch(tipo) {
            case "Libros"->new LibroDAO();
            case "Estudiantes"->new EstudianteDAO();
            case "Categorías"->new CategoriaDAO();
            case "Usuarios"->new UsuarioDAO();
            default->throw new IllegalArgumentException("Entidad inválida");
        }
        ;
    }
    public synchronized void guardar(Usuario u,String tipo,Entidad e)throws SQLException {
        admin(u);
        if(e instanceof Usuario user) {
            if(user.getId()==u.getId()&&!user.puedeAdministrar())throw new IllegalArgumentException("No puedes quitar tu propio rol");
            if(!user.puedeAdministrar())consultas.estudiantePorRut(user.getRut());
        }
        if(e instanceof Estudiante st) {
            Estudiante anterior=st.getId()==0?null:new EstudianteDAO().buscar(st.getId());
            db.transaccion(c-> {
                new EstudianteDAO().guardar(c,st);if(anterior!=null)try(var s=c.prepareStatement("UPDATE usuarios SET nombre=?,rut=?,correo=? WHERE rut=? AND rol='estudiante'")) {
                    s.setString(1,st.getNombre());s.setString(2,st.getRut());s.setString(3,st.getCorreo());s.setString(4,anterior.getRut());s.executeUpdate();
                }
                return null;
            }
            );
            return;
        }
        switch (tipo) {
            case "Libros" -> new LibroDAO().guardar((Libro) e);
            case "Categorías" -> new CategoriaDAO().guardar((Categoria) e);
            case "Usuarios" -> new UsuarioDAO().guardar((Usuario) e);
            default -> throw new IllegalArgumentException("Entidad inválida");
        }
    }
    public synchronized void eliminar(Usuario u,String tipo,int id)throws SQLException {
        admin(u);
        if(tipo.equals("Usuarios")&&id==u.getId())throw new IllegalArgumentException("No puedes eliminar tu propia cuenta");
        if(tipo.equals("Estudiantes")) {
            Estudiante st=new EstudianteDAO().buscar(id);
            if(st!=null&&consultas.consulta("SELECT id FROM usuarios WHERE rut=? AND rol='estudiante'",st.getRut()).filas().size()>0)throw new IllegalArgumentException("Elimina primero la cuenta del estudiante");
        }
        dao(tipo).eliminar(id);
    }
}
