package cl.eft.biblioteca.model;
public abstract class Usuario extends Persona  {
    private final String password;
    protected Usuario(int id,String nombre,String rut,String correo,String password) {
        super(id,nombre,rut,correo);
        this.password=password;
    }
    public String getPassword() {
        return password;
    }
    public abstract boolean puedeAdministrar();
    public abstract String getRol();
    public String descripcion() {
        return getNombre()+" ("+getRol()+")";
    }
    public static Usuario crear(int id,String nombre,String rut,String correo,String password,String rol) {
        if("BIBLIOTECARIO".equals(rol))return new Bibliotecario(id,nombre,rut,correo,password);
        if("ESTUDIANTE".equals(rol))return new UsuarioEstudiante(id,nombre,rut,correo,password);
        throw new IllegalArgumentException("Rol inválido");
    }
}
