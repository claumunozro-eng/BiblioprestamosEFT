package cl.eft.biblioteca.dao;
import cl.eft.biblioteca.model.*;
import java.sql.*;
public final class LibroDAO extends JdbcDAO<Libro> {
    public LibroDAO() {
        super("libros","titulo,autor,isbn,editorial,stock,id_categoria");
    }
    protected Libro map(ResultSet r)throws SQLException {
        return new Libro(r.getInt("id"),r.getString("titulo"),r.getString("autor"),r.getString("isbn"),r.getString("editorial"),r.getInt("stock"),r.getInt("id_categoria"));
    }
    protected Object[] values(Libro e) {
        return new Object[] {
            e.getTitulo(),e.getAutor(),e.getIsbn(),e.getEditorial(),e.getStock(),e.getIdCategoria()
        }
        ;
    }
}
