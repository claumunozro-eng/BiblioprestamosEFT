package cl.eft.biblioteca.dao;
import cl.eft.biblioteca.model.Entidad;
import java.sql.SQLException;
import java.util.List;
public interface CrudDAO<T extends Entidad> {
    List<T> listar()throws SQLException;
    T buscar(int id)throws SQLException;
    void guardar(T entidad)throws SQLException;
    void eliminar(int id)throws SQLException;
}
