package cl.eft.biblioteca.controller;
import cl.eft.biblioteca.model.*;
import cl.eft.biblioteca.view.*;
import cl.eft.biblioteca.service.*;
import cl.eft.biblioteca.dao.*;
import cl.eft.biblioteca.util.*;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.function.Consumer;
/** Eventos y tareas SwingWorker; la vista nunca ejecuta JDBC. */
public final class BibliotecaController  {
    private final BibliotecaService service=new BibliotecaService();
    private MainView main;
    private Usuario usuario;
    private int pendientes;
    public void iniciar() {
        LoginView login=new LoginView();
        login.entrar.addActionListener(e-> {
            login.entrar.setEnabled(false);login.estado.setText("Conectando…");String correo=login.correo.getText();char[] password=login.password.getPassword();login.password.setText("");new SwingWorker<Usuario,Void>() {
                protected Usuario doInBackground()throws Exception {
                    return service.login(correo,password);
                }
                protected void done() {
                    try {
                        usuario=get();login.dispose();abrir();
                    }
                    catch(Exception ex) {
                        login.estado.setText("No se pudo ingresar");error(login,ex);
                    }
                    finally {
                        login.entrar.setEnabled(true);
                    }
                }
            }
            .execute();
        }
        );
        login.setVisible(true);
    }
    private <T>void tarea(JButton button,Callable<T> action,Consumer<T> done) {
        button.setEnabled(false);
        pendientes++;
        main.estado.setText("Procesando en segundo plano…");
        new SwingWorker<T,Void>() {
            protected T doInBackground()throws Exception {
                return action.call();
            }
            protected void done() {
                try {
                    done.accept(get());
                }
                catch(Exception ex) {
                    error(main,ex);
                }
                finally {
                    button.setEnabled(true);
                    pendientes--;
                    main.estado.setText(pendientes==0?"Listo":"Procesando en segundo plano…");
                }
            }
        }
        .execute();
    }
    private void error(Component c,Throwable ex) {
        while(ex.getCause()!=null)ex=ex.getCause();
        String msg=ex.getMessage();
        if(ex instanceof java.sql.SQLIntegrityConstraintViolationException)msg="No se pudo guardar o eliminar: existe un RUT, correo o ISBN repetido, o hay registros relacionados. Revisa los datos y el historial.";
        JOptionPane.showMessageDialog(c,msg==null?ex.toString():msg,"Revisa la operación",JOptionPane.ERROR_MESSAGE);
    }
    private void abrir() {
        main=new MainView(usuario.descripcion());
        main.salir.addActionListener(e-> {
            if(pendientes>0) {
                JOptionPane.showMessageDialog(main,"Espera a que terminen las operaciones.");return;
            }
            main.dispose();usuario=null;iniciar();
        }
        );
        catalogo();
        if(usuario.puedeAdministrar()) {
            crud("Libros",new String[] {
                "Título","Autor","ISBN","Editorial","Stock disponible","ID categoría"
            }
            );
            crud("Estudiantes",new String[] {
                "Nombre","RUT","Curso","Correo"
            }
            );
            crud("Categorías",new String[] {
                "Nombre"
            }
            );
            crud("Usuarios",new String[] {
                "Nombre","RUT","Correo","Contraseña nueva (vacía conserva)","Rol BIBLIOTECARIO o ESTUDIANTE"
            }
            );
        }
        circulacion();
        reportes();
        main.setVisible(true);
    }
    private void catalogo() {
        JTable t=MainView.tabla();
        JButton b=new JButton("Actualizar catálogo");
        b.addActionListener(e->tarea(b,service::catalogo,r->MainView.mostrar(t,r)));
        main.tabs.addTab("Catálogo",MainView.listado(t,b));
        b.doClick();
    }
    private void crud(String tipo,String[] labels) {
        MainView.CrudPanel p=new MainView.CrudPanel(labels);
        final List<Entidad> rows=new ArrayList<>();
        Runnable refresh=()->tarea(p.actualizar,()->service.listar(usuario,tipo),data-> {
            rows.clear();rows.addAll(data);String[] columns=new String[labels.length+1];columns[0]="ID";System.arraycopy(labels,0,columns,1,labels.length);List<Object[]> values=new ArrayList<>();for(Entidad en:rows) {
                Object[] v=valores(en);Object[] row=new Object[v.length+1];row[0]=en.getId();System.arraycopy(v,0,row,1,v.length);values.add(row);
            }
            MainView.mostrar(p.tabla,new ConsultaDAO.Tabla(columns,values));p.limpiar();
        }
        );
        p.actualizar.addActionListener(e->refresh.run());
        p.nuevo.addActionListener(e->p.limpiar());
        p.tabla.getSelectionModel().addListSelectionListener(e-> {
            if(e.getValueIsAdjusting()||p.tabla.getSelectedRow()<0)return;int i=p.tabla.convertRowIndexToModel(p.tabla.getSelectedRow());if(i>=rows.size())return;Entidad en=rows.get(i);p.id=en.getId();Object[] v=valores(en);int k=0;for(JTextField field:p.campos.values())field.setText(String.valueOf(v[k++]));
        }
        );
        p.guardar.addActionListener(e-> {
            try {
                String[] v=p.campos.values().stream().map(f->f.getText().trim()).toArray(String[]::new);Entidad previous=rows.stream().filter(x->x.getId()==p.id).findFirst().orElse(null);Entidad en=crear(tipo,p.id,v,previous);tarea(p.guardar,()-> {
                    service.guardar(usuario,tipo,en);return true;
                }
                ,ok-> {
                    p.limpiar();refresh.run();
                }
                );
            }
            catch(Exception ex) {
                error(main,ex);
            }
        }
        );
        p.eliminar.addActionListener(e-> {
            int id=p.id;if(id<1) {
                error(main,new IllegalArgumentException("Selecciona un registro"));return;
            }
            if(JOptionPane.showConfirmDialog(main,"¿Eliminar el registro "+id+"? Los registros con historial no pueden eliminarse.","Confirmar eliminación",JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION)return;tarea(p.eliminar,()-> {
                service.eliminar(usuario,tipo,id);return true;
            }
            ,ok->refresh.run());
        }
        );
        main.tabs.addTab(tipo,p);
        refresh.run();
    }
    private Object[] valores(Entidad e) {
        if(e instanceof Libro x)return new Object[] {
            x.getTitulo(),x.getAutor(),x.getIsbn(),x.getEditorial(),x.getStock(),x.getIdCategoria()
        }
        ;
        if(e instanceof Estudiante x)return new Object[] {
            x.getNombre(),x.getRut(),x.getCurso(),x.getCorreo()
        }
        ;
        if(e instanceof Categoria x)return new Object[] {
            x.getNombre()
        }
        ;
        if(e instanceof Usuario x)return new Object[] {
            x.getNombre(),x.getRut(),x.getCorreo(),"",x.getRol()
        }
        ;
        throw new IllegalArgumentException();
    }
    private int entero(String v) {
        try {
            return Integer.parseInt(v);
        }
        catch(NumberFormatException e) {
            throw new IllegalArgumentException("Ingresa números enteros para los IDs y el stock");
        }
    }
    private void correo(String s) {
        if(!s.matches("[^\\s@]+@[^\\s@]+\\.[^\\s@]+"))throw new IllegalArgumentException("Correo inválido");
    }
    private Entidad crear(String tipo,int id,String[] v,Entidad previous) {
        for(int i=0;i<v.length;i++) {
            if(tipo.equals("Usuarios")&&i==3)continue;
            if(v[i].isBlank())throw new IllegalArgumentException("Completa todos los campos");
            int max=tipo.equals("Libros")?(i==0?200:i==2?20:100):tipo.equals("Estudiantes")?(i==1?12:i==2?20:100):tipo.equals("Usuarios")?(i==1?12:i==3?150:100):100;
            if(v[i].length()>max)throw new IllegalArgumentException("Campo demasiado largo (máximo "+max+")");
        }
        return switch(tipo) {
            case "Libros"-> {
                int stock=entero(v[4]),cat=entero(v[5]);
                if(stock<0||cat<1)throw new IllegalArgumentException("Stock no negativo y categoría válida");
                yield new Libro(id,v[0],v[1],v[2],v[3],stock,cat);
            }
            case "Estudiantes"-> {
                correo(v[3]);
                yield new Estudiante(id,v[0],v[1],v[2],v[3]);
            }
            case "Categorías"->new Categoria(id,v[0]);
            case "Usuarios"-> {
                correo(v[2]);
                String hash;
                if(v[3].isBlank()) {
                    if(!(previous instanceof Usuario x))throw new IllegalArgumentException("Ingresa una contraseña para el nuevo usuario");
                    hash=x.getPassword();
                }
                else {
                    if(v[3].length()<8)throw new IllegalArgumentException("La contraseña debe tener al menos 8 caracteres");
                    hash=PasswordUtil.hash(v[3].toCharArray());
                }
                yield Usuario.crear(id,v[0],v[1],v[2],hash,v[4].toUpperCase(Locale.ROOT));
            }
            default->throw new IllegalArgumentException();
        }
        ;
    }
    private void circulacion() {
        JTable t=MainView.tabla();
        JPanel b=new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField student=new JTextField(5),book=new JTextField(5);
        JButton prestar=new JButton("Prestar"),devolver=new JButton("Devolver seleccionado"),actualizar=new JButton("Actualizar");
        if(usuario.puedeAdministrar()) {
            b.add(new JLabel("ID estudiante"));
            b.add(student);
        }
        b.add(new JLabel("ID libro"));
        b.add(book);
        b.add(prestar);
        b.add(devolver);
        b.add(actualizar);
        Runnable refresh=()->tarea(actualizar,()->service.prestamos(usuario),r->MainView.mostrar(t,r));
        actualizar.addActionListener(e->refresh.run());
        prestar.addActionListener(e-> {
            try {
                int es=usuario.puedeAdministrar()?entero(student.getText().trim()):0,li=entero(book.getText().trim());tarea(prestar,()->service.prestar(usuario,es,li),id-> {
                    JOptionPane.showMessageDialog(main,"Préstamo "+id+" registrado. Actualiza el catálogo para ver el stock.");refresh.run();
                }
                );
            }
            catch(Exception ex) {
                error(main,ex);
            }
        }
        );
        devolver.addActionListener(e-> {
            if(t.getSelectedRow()<0) {
                error(main,new IllegalArgumentException("Selecciona un préstamo"));return;
            }
            int id=((Number)t.getValueAt(t.getSelectedRow(),0)).intValue();tarea(devolver,()->service.devolver(usuario,id),dias-> {
                JOptionPane.showMessageDialog(main,"Devolución registrada. Días de atraso: "+dias);refresh.run();
            }
            );
        }
        );
        main.tabs.addTab("Préstamos y devoluciones",MainView.listado(t,b));
        refresh.run();
    }
    private void reportes() {
        JTable t=MainView.tabla();
        JPanel b=new JPanel(new FlowLayout(FlowLayout.LEFT));
        JComboBox<String> tipo=new JComboBox<>(usuario.puedeAdministrar()?new String[] {
            "Más prestados","Historial","Actualmente prestados"
        }
        :new String[] {
            "Historial"
        }
        );
        JTextField student=new JTextField(5);
        JButton ver=new JButton("Generar reporte");
        b.add(tipo);
        if(usuario.puedeAdministrar()) {
            b.add(new JLabel("ID estudiante (para historial)"));
            b.add(student);
        }
        b.add(ver);
        ver.addActionListener(e-> {
            try {
                String selected=(String)tipo.getSelectedItem();int id=usuario.puedeAdministrar()&&selected.equals("Historial")?entero(student.getText().trim()):0;tarea(ver,()->service.reporte(usuario,selected,id),r->MainView.mostrar(t,r));
            }
            catch(Exception ex) {
                error(main,ex);
            }
        }
        );
        main.tabs.addTab("Reportes",MainView.listado(t,b));
    }
}
