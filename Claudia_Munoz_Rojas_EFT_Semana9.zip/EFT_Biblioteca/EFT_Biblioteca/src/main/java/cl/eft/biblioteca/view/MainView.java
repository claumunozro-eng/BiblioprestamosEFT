package cl.eft.biblioteca.view;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.*;
import cl.eft.biblioteca.dao.ConsultaDAO;
public final class MainView extends JFrame  {
    public final JTabbedPane tabs=new JTabbedPane();
    public final JLabel estado=new JLabel("Listo");
    public final JButton salir=new JButton("Cerrar sesión");
    public MainView(String persona) {
        super("Biblioteca escolar · "+persona);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1120,720);
        setMinimumSize(new Dimension(850,560));
        setLocationRelativeTo(null);
        JPanel top=new JPanel(new BorderLayout());
        top.setBorder(BorderFactory.createEmptyBorder(10,12,10,12));
        top.add(new JLabel(persona),BorderLayout.WEST);
        top.add(salir,BorderLayout.EAST);
        add(top,BorderLayout.NORTH);
        add(tabs,BorderLayout.CENTER);
        estado.setBorder(BorderFactory.createEmptyBorder(10,12,10,12));
        add(estado,BorderLayout.SOUTH);
    }
    public static JTable tabla() {
        JTable t=new JTable(new DefaultTableModel() {
            public boolean isCellEditable(int r,int c) {
                return false;
            }
        }
        );
        t.setRowHeight(25);
        t.setAutoCreateRowSorter(true);
        t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        return t;
    }
    public static void mostrar(JTable t,ConsultaDAO.Tabla datos) {
        DefaultTableModel m=new DefaultTableModel(datos.columnas(),0) {
            public boolean isCellEditable(int r,int c) {
                return false;
            }
        }
        ;
        for(Object[] row:datos.filas())m.addRow(row);
        t.setModel(m);
    }
    public static JPanel listado(JTable tabla,JComponent botones) {
        JPanel p=new JPanel(new BorderLayout(8,8));
        p.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        p.add(botones,BorderLayout.NORTH);
        p.add(new JScrollPane(tabla),BorderLayout.CENTER);
        return p;
    }
    public static final class CrudPanel extends JPanel  {
        public final JTable tabla=MainView.tabla();
        public final JButton nuevo=new JButton("Nuevo"),guardar=new JButton("Guardar"),eliminar=new JButton("Eliminar"),actualizar=new JButton("Actualizar");
        public final Map<String,JTextField> campos=new LinkedHashMap<>();
        public int id;
        public CrudPanel(String[] labels) {
            super(new BorderLayout(8,8));
            setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
            JPanel form=new JPanel(new GridLayout(0,2,8,6));
            for(String label:labels) {
                form.add(new JLabel(label));
                JTextField f=label.startsWith("Contraseña")?new JPasswordField(20):new JTextField(20);
                campos.put(label,f);
                form.add(f);
            }
            JPanel buttons=new JPanel(new FlowLayout(FlowLayout.LEFT));
            buttons.add(nuevo);
            buttons.add(guardar);
            buttons.add(eliminar);
            buttons.add(actualizar);
            JPanel north=new JPanel(new BorderLayout());
            north.add(form,BorderLayout.CENTER);
            north.add(buttons,BorderLayout.SOUTH);
            add(north,BorderLayout.NORTH);
            add(new JScrollPane(tabla),BorderLayout.CENTER);
        }
        public void limpiar() {
            id=0;
            campos.values().forEach(f->f.setText(""));
            tabla.clearSelection();
        }
    }
}
