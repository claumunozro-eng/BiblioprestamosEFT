@echo off
cd /d "%~dp0"
if not exist work\test-classes mkdir work\test-classes
javac -encoding UTF-8 --release 17 -cp dist\biblioteca.jar -d work\test-classes src\test\java\cl\eft\biblioteca\*.java
if errorlevel 1 exit /b 1
java -cp "dist\biblioteca.jar;work\test-classes" cl.eft.biblioteca.PruebasBasicas
if /I "%~1"=="mysql" java -cp "dist\biblioteca.jar;work\test-classes" cl.eft.biblioteca.PruebaConcurrencia
