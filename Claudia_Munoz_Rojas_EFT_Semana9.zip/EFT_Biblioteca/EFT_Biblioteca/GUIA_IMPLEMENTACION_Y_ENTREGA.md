# Implementación y entrega de la EFT de POO II

El proyecto ya contiene el desarrollo de la aplicación. Tu trabajo posterior consiste en configurar MySQL, ejecutar y comprobar el sistema, comprender su código, grabar el video y publicar la entrega. No entregues el ZIP sin hacer estas verificaciones.

## 1 Extraer y abrir el proyecto

1. Extrae `EFT_Biblioteca.zip` en una carpeta de trabajo.
2. Abre IntelliJ IDEA, selecciona **Open** y elige la carpeta `EFT_Biblioteca` que contiene `pom.xml`.
3. Configura el SDK del proyecto con Java 17 o posterior y permite que IntelliJ importe las dependencias Maven. El código se compila para Java 17.
4. El archivo `dist/biblioteca.jar` ya está construido e incluye el controlador MySQL. No necesitas recompilar para la primera ejecución. Para reconstruirlo después de editar, ejecuta `compilar.bat`, que usa Maven, requiere acceso a sus dependencias y copia el resultado a `dist`.

## 2 Preparar la base de datos oficial

Usa MySQL 8.0.16 o posterior y un cliente, por ejemplo MySQL Workbench. Conéctate a tu servidor con una cuenta que pueda crear tablas. Ejecuta los archivos completos en este orden:

1. `sql/PRY2203_EFT_S9_Script_crea_tablas_biblioteca.sql`.
2. `sql/PRY2203_EFT_S9_Script_poblado_tablas_biblioteca.sql`.
3. `sql/03_adecuaciones_eft.sql`.
4. Opcionalmente, `sql/04_usuario_local.sql`, después de reemplazar `CAMBIAR_PASSWORD_LOCAL` por una contraseña local elegida por ti.

Los archivos oficiales se incluyen sin modificaciones. El tercer script amplía el largo de `contraseña` para PBKDF2, exige correos únicos de usuarios, agrega fecha real y días de atraso y asegura tablas InnoDB y stock no negativo. Se ejecuta una sola vez. Estas son ampliaciones explícitas al esquema oficial y debes mencionarlas en el video.

**Si ya tienes una base llamada `biblioteca` con información**, haz primero una copia de respaldo y revisa su contenido. No vuelvas a poblarla encima: los scripts oficiales no son idempotentes y pueden producir errores o duplicados. Para esta EFT conviene trabajar con una instalación de prueba separada. No borres una base que uses para otro proyecto.

Tras ejecutar los dos scripts oficiales verifica inicialmente: 10 usuarios, 10 estudiantes, 5 categorías, 10 libros y 10 préstamos. La fecha real de las devoluciones históricas queda sin dato porque el script no la proporciona. Sus préstamos de 2025 pueden aparecer atrasados al ejecutar hoy; eso es esperable.

El stock oficial se interpreta como ejemplares disponibles y se conserva. No se descuenta nuevamente por los préstamos ya insertados, porque la pauta no establece si el stock original era total o disponible. Si tu docente indica otra interpretación, ajusta los datos con esa instrucción.

## 3 Configurar la conexión

1. Copia `config/database.properties.example` y renombra la copia como `config/database.properties`.
2. Edita `db.url` si el servidor o puerto es distinto; por defecto apunta a `localhost:3306/biblioteca`.
3. Escribe en `db.user` la cuenta MySQL que usarás. Si ejecutaste el cuarto script, es `biblioteca_app`.
4. Escribe su clave en `db.password`. No es la contraseña de un usuario de la biblioteca: son credenciales distintas.
5. Deja `prestamo.dias=7` o cambia el plazo si el docente lo indica.

Este archivo real se excluye de Git mediante `.gitignore`. Puedes usar también las variables `BIBLIOTECA_DB_URL`, `BIBLIOTECA_DB_USER` y `BIBLIOTECA_DB_PASSWORD`, que tienen prioridad sobre el archivo.

En IntelliJ configura el directorio de trabajo de la ejecución como la carpeta raíz del proyecto; de lo contrario no encontrará `config/database.properties`.

## 4 Convertir las contraseñas de los datos oficiales

Ejecuta `migrar-claves.bat` después de configurar MySQL y ejecutar el tercer script. Debe informar **Contraseñas convertidas: 10** la primera vez. Si lo ejecutas de nuevo, debe informar 0, porque no vuelve a transformar las claves ya protegidas.

El script oficial guarda `clave123` en texto plano. La aplicación exige la conversión para autenticar esos usuarios. La clave que escribes en la pantalla sigue siendo `clave123`, aunque su representación en la base cambia. No cambies las contraseñas de la base manualmente por un texto plano después de la conversión.

## 5 Ejecutar y recorrer las funcionalidades

Ejecuta `ejecutar.bat` o abre `cl.eft.biblioteca.App` en IntelliJ y pulsa Run. También puedes iniciar el JAR desde la carpeta raíz con:

```powershell
java -jar dist/biblioteca.jar
```

Cuentas del material oficial:

| Rol | Correo | Clave inicial |
|---|---|---|
| Bibliotecaria | antonia@correo.cl | clave123 |
| Estudiante | carlos@correo.cl | clave123 |
| Estudiante | maria@correo.cl | clave123 |

Estas cuentas sirven para una base de demostración. Para mostrar el sistema usa las cuentas ficticias proporcionadas por la actividad.

**Como bibliotecaria:** consulta el catálogo, revisa las pestañas de administración y los tres reportes. En un CRUD, pulsa Nuevo, completa los campos y Guarda; selecciona una fila para modificarla o eliminarla. Los IDs aparecen en las tablas. Para un libro, usa el ID de una categoría existente. El campo Stock representa ejemplares disponibles. Para probar eliminación, crea registros temporales sin historial; las relaciones impiden borrar libros o estudiantes con préstamos registrados.

**Registrar un nuevo estudiante:** crea primero el registro en Estudiantes. Luego crea su cuenta en Usuarios con el mismo RUT, correo y nombre, una clave de al menos ocho caracteres y rol `ESTUDIANTE`. La vinculación se realiza por RUT y no requiere que ambos IDs sean iguales. Por ejemplo, el script contiene a Luis como estudiante pero no tiene una cuenta de usuario para él: puedes crearla siguiendo este proceso. Cuando editas un estudiante, la cuenta estudiantil ya vinculada actualiza nombre, RUT y correo en la misma transacción.

**Préstamo:** en Préstamos y devoluciones escribe ID estudiante e ID libro y pulsa Prestar. Se calcula el vencimiento automáticamente. Actualiza el catálogo para ver el stock actualizado. En el historial debes ver el nuevo préstamo. Para devolverlo, selecciona su fila y pulsa Devolver seleccionado. Aparece la cantidad de días de atraso y el stock aumenta una vez.

**Como Carlos:** se muestran catálogo, préstamos propios y su historial. El ID del estudiante se resuelve por su RUT. No puedes administrar entidades, consultar historial ajeno ni devolver préstamos de otras personas. El catálogo contiene los IDs de libros para solicitar un préstamo.

## 6 Ejecutar pruebas y guardar evidencia real

Ejecuta `probar.bat` para las comprobaciones básicas. Para probar MySQL de verdad ejecuta desde una terminal situada en la carpeta del proyecto:

```powershell
.\probar.bat mysql
```

La prueba MySQL crea registros temporales identificados como TEST, intenta ocho préstamos concurrentes de un libro con stock 1 y espera un éxito y siete rechazos; además verifica el stock y una doble devolución. Al finalizar intenta limpiar únicamente sus registros. Ejecútala en la base de prueba, con permiso para insertar y eliminar. Un mensaje de error no cuenta como prueba aprobada: corrige la causa y repite.

Completa también [docs/PLAN_PRUEBAS.md](docs/PLAN_PRUEBAS.md) y guarda tus capturas o resultados. No se han ejecutado aquí las pruebas con MySQL ni una inspección visual de la interfaz. El informe de verificación distingue los resultados comprobados y los pendientes.

## 7 Entender el código para explicarlo

1. `model/Persona.java`, `Usuario.java`, `Bibliotecario.java`, `UsuarioEstudiante.java` y `Estudiante.java`: herencia, abstracción y polimorfismo. Mira cómo una referencia `Usuario` responde de forma distinta a `puedeAdministrar()`.
2. `dao/CrudDAO.java` y `JdbcDAO.java`: interfaz genérica y reutilización del CRUD. Los cinco DAO concretos convierten registros SQL en objetos.
3. `config/DatabaseConnection.java`: Singleton, conexión con `DriverManager.getConnection`, sincronización, commit y rollback.
4. `service/BibliotecaService.java` y `dao/CirculacionDAO.java`: permisos, préstamo transaccional, stock protegido, devolución y atraso.
5. `controller/BibliotecaController.java`: eventos y `SwingWorker`. `doInBackground()` trabaja fuera del hilo de la interfaz y `done()` presenta los resultados.
6. `view/LoginView.java` y `MainView.java`: pantallas JFrame y navegación.

No es necesario reescribir estas clases para entregar. Sí debes poder explicar y demostrar lo que hacen. Si realizas cambios, recompila y repite las pruebas afectadas.

## 8 Grabar el video en Kaltura

La pauta pide **3 a 5 minutos**, funcionamiento de la aplicación, IDE con código, explicación de MVC, DAO, Singleton, hilos y sincronización, y tu rostro visible en alguna parte. Usa [docs/GUION_VIDEO.md](docs/GUION_VIDEO.md) como apoyo, adaptándolo a lo que tú verificaste.

Prepara las ventanas y los registros de ejemplo antes de grabar. Puedes demostrar el préstamo vencido número 1 del material oficial para explicar el atraso. No digas que una prueba pasó si no la ejecutaste. Reproduce el video final y revisa duración, audio, legibilidad del código y aparición de tu rostro.

## 9 Publicar en GitHub

1. Crea un repositorio **público** en tu cuenta.
2. Sube la carpeta del proyecto con código, `pom.xml`, scripts SQL, guías, pruebas y ejecutable. No subas `config/database.properties` con tu clave MySQL.
3. Puedes usar GitHub Desktop para agregar el proyecto, revisar los cambios y publicarlo, o Git desde IntelliJ.
4. Usa commits descriptivos que correspondan a cambios reales, por ejemplo la incorporación del proyecto, la configuración que tú ajustes y las correcciones resultantes de tus pruebas. No inventes una historia de desarrollo.
5. Abre el enlace público en una ventana privada para verificar que el código sea visible. Si la plataforma impide subir el JAR por tamaño, publícalo como archivo de una Release y mantén el JAR dentro del ZIP de entrega.

No se creó ni publicó un repositorio en tu nombre desde este chat.

## 10 Preparar y subir la entrega

Tras verificar el sistema, comprime de nuevo la carpeta final para incorporar tus cambios y evidencias. Incluye código fuente, los dos scripts oficiales, las adecuaciones SQL, el JAR en `dist`, `pom.xml` y la guía de ejecución. Para que el docente pueda configurar su MySQL, incluye el ejemplo de configuración y las instrucciones; no incluyas una contraseña personal.

En AVA sube el ZIP o RAR, entrega el video de Kaltura y pega el enlace de tu repositorio público. Comprueba que el archivo comprimido se pueda extraer, que el JAR esté dentro y que la publicación del video sea accesible. La pauta solicita el proyecto, la base configurada y un ejecutable funcional: los scripts y la guía permiten reconstruir la base, pero debes demostrar que funciona en tu instalación antes de entregar. Si tu sección exige además un respaldo exportado de MySQL, exporta tu base de demostración con Workbench y agrégalo sin credenciales personales.

## Problemas frecuentes

| Mensaje o síntoma | Acción |
|---|---|
| Access denied for user | Revisa cuenta, clave y permisos MySQL en el archivo real de configuración. |
| Communications link failure | Inicia el servicio MySQL y revisa servidor y puerto. |
| Unknown database biblioteca | Ejecuta el primer script en el servidor al que apunta la aplicación. |
| Unknown column fecha_devolucion_real | Falta ejecutar `03_adecuaciones_eft.sql`. |
| Correo o contraseña incorrectos con clave123 | Ejecuta `migrar-claves.bat` y confirma que estás usando la misma base. |
| No suitable driver | Usa el JAR de `dist` o carga correctamente la dependencia Maven en IntelliJ. |
| Duplicate column o Constraint already exists | Probablemente repetiste el tercer script; revisa el esquema antes de ejecutarlo otra vez. |
| Error de clave foránea al eliminar | El registro tiene historial o relaciones. Prueba borrar uno temporal sin relaciones. |
| UnsupportedClassVersionError | Configura Java 17 o posterior para ejecutar. |
| El usuario no está vinculado a un estudiante | Crea el estudiante y comprueba que su RUT coincide exactamente con la cuenta. |
