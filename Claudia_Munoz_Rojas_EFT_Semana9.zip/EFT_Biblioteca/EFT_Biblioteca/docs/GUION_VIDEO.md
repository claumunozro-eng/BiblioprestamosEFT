# Guion sugerido para un video de cuatro minutos

Usa este guion como apoyo. Ensaya con el sistema configurado, modifica el texto para que corresponda a lo que tú comprendiste y muestra únicamente resultados que hayas verificado.

## 0 a 20 segundos Presentación con rostro visible

“Soy [tu nombre] y presentaré mi sistema de gestión de biblioteca escolar para la EFT de Desarrollo Orientado a Objetos II. Es una aplicación de escritorio en Java con interfaz JFrame y base de datos MySQL.”

## 20 a 65 segundos Acceso y administración

Entra como Antonia. Muestra catálogo y CRUD de libros. Crea o modifica un libro temporal que ya preparaste, consulta su categoría y stock. Muestra brevemente Estudiantes, Categorías y Usuarios.

“El bibliotecario administra los registros. Los estudiantes tienen permisos de consulta y circulación propia. Estudiantes y cuentas se vinculan por el RUT. Hay CRUD de libros, estudiantes, categorías y usuarios.”

## 65 a 125 segundos Circulación y reportes

Registra un préstamo, muestra su vencimiento y actualiza el catálogo para comprobar que el stock bajó. Devuelve el préstamo y muestra que aumenta. Si alcanza el tiempo, muestra un préstamo vencido y los días de atraso. Abre los tres reportes.

“El plazo se calcula automáticamente. El préstamo y el cambio de stock se confirman en una misma transacción. El registro de préstamo forma también el historial. Una devolución guarda su fecha real y atraso, y no se puede repetir.”

## 125 a 155 segundos Rol estudiante

Cierra sesión e ingresa como Carlos. Muestra que no están las pestañas administrativas y que solo ve sus préstamos e historial. No es necesario repetir toda la operación.

## 155 a 215 segundos Código y decisiones

Abre IntelliJ con estas clases preparadas:

* `Persona` y las subclases de `Usuario`: “La clase abstracta Persona reúne datos comunes. Las subclases sobrescriben permisos y descripciones, de modo que el mismo método responde según el tipo del objeto.”
* `CrudDAO` y un DAO concreto: “La interfaz define las operaciones de persistencia y los DAO encapsulan SQL. Modelo, vista y controlador se mantienen separados.”
* `DatabaseConnection`: “getInstance aplica Singleton. La conexión se crea con DriverManager y las transacciones confirman o revierten los cambios.”
* `BibliotecaController` y `BibliotecaService`: “SwingWorker ejecuta el acceso a datos en segundo plano. synchronized coordina procesos críticos en esta aplicación; el UPDATE condicionado al stock y el bloqueo de devolución protegen también la consistencia en la base.”

## 215 a 240 segundos Evidencia y entrega

Si ejecutaste la prueba de concurrencia, muestra su salida brevemente y explica el resultado real. Muestra el repositorio público y la estructura de archivos.

“Utilicé los dos scripts oficiales y una ampliación para fecha real de devolución, atraso y protección de contraseñas. El proyecto contiene código fuente, scripts y un JAR ejecutable. El repositorio público está disponible en [tu enlace].”

Revisa que el video dure entre tres y cinco minutos, que tu rostro aparezca, que el audio sea claro y que el código resulte legible. No publiques contraseñas personales de MySQL en la grabación.
