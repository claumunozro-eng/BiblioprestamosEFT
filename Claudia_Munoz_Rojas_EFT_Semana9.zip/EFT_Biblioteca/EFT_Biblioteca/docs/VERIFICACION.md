# Verificación del desarrollo

## Comprobado durante la preparación

* El código principal se compiló con destino Java 17.
* Se ejecutaron siete comprobaciones: contraseña válida, rechazo de clave incorrecta, rechazo de formato inválido, permisos según subclase, herencia, identidad Singleton y plazo predeterminado.
* Se conservaron sin cambios los dos archivos SQL oficiales proporcionados.
* El JAR incorpora las clases de la aplicación y MySQL Connector/J 9.4.0, con su dependencia protobuf.

## Pendiente en el computador de entrega

* Ejecutar los scripts contra un servidor MySQL.
* Ejecutar la conversión de claves y autenticar las cuentas oficiales.
* Probar CRUD, reportes, préstamo, devolución y persistencia.
* Ejecutar la prueba de concurrencia incluida.
* Verificar visualmente todas las ventanas y la respuesta de Swing durante procesos.
* Probar el JAR desde el ZIP final extraído, grabar el video y publicar en GitHub.

No había un servidor MySQL disponible en el entorno de preparación. Por ello no se declara que el flujo integrado haya sido probado ni que el producto esté listo para entregar sin las verificaciones anteriores.
