# Pruebas funcionales previas a la entrega

Completa Resultado real con aprobado o fallido, fecha y una descripción breve. Las filas inicialmente están pendientes; no constituyen evidencia de ejecución.

| Caso | Acción | Resultado esperado | Resultado real |
|---|---|---|---|
| Acceso correcto | Entrar como Antonia después de migrar claves | Todas las pestañas administrativas visibles | Pendiente |
| Acceso rechazado | Entrar con una clave incorrecta | Mensaje y permanencia en acceso | Pendiente |
| Rol estudiante | Entrar como Carlos | Catálogo, préstamos propios e historial propio | Pendiente |
| CRUD categorías | Crear, listar, editar y eliminar una categoría temporal | Persistencia al volver a consultar | Pendiente |
| CRUD libros | Crear libro temporal, editar y eliminar | Persistencia, stock no negativo y categoría existente | Pendiente |
| CRUD estudiantes | Crear, editar y eliminar estudiante temporal sin cuenta ni historial | Cambios persistidos | Pendiente |
| CRUD usuarios | Crear cuenta para estudiante temporal, editar contraseña y eliminar | Acceso con nueva clave y rechazo de anterior | Pendiente |
| Vínculo estudiante | Crear estudiante y usuario con mismo RUT | Sus préstamos e historial se asocian a la persona correcta | Pendiente |
| Sin stock | Pedir préstamo de libro con stock 0 | Rechazo sin nuevo préstamo | Pendiente |
| Préstamo válido | Prestar un ejemplar disponible | Stock disminuye 1 e historial incorpora préstamo | Pendiente |
| Vencimiento | Consultar préstamo nuevo | Fecha actual más plazo configurado | Pendiente |
| Concurrencia | Ejecutar `probar.bat mysql` | Un éxito y siete rechazos con stock inicial 1 | Pendiente |
| Devolución | Devolver un préstamo abierto | Stock aumenta 1, se guarda fecha efectiva | Pendiente |
| Doble devolución | Intentar devolver la misma fila otra vez | Rechazo; stock no aumenta nuevamente | Pendiente |
| Atraso | Devolver préstamo vencido número 1 de los datos oficiales | Días de atraso coherentes con vencimiento | Pendiente |
| Interfaz receptiva | Durante una consulta o préstamo mover la ventana o cambiar pestaña | Ventana responde; se muestra estado de procesamiento | Pendiente |
| Historial | Consultar un estudiante con préstamos abiertos y devueltos | Todas sus operaciones incluidas | Pendiente |
| Más prestados | Generar reporte | Libros ordenados por cantidad total de préstamos | Pendiente |
| Actualmente prestados | Generar reporte | Solo préstamos con devuelto=false | Pendiente |
| Integridad | Intentar borrar libro con historial | Rechazo sin pérdida de datos | Pendiente |
| Reinicio | Cerrar y reabrir aplicación | Datos guardados continúan presentes | Pendiente |
| Distribución | Extraer ZIP en otra carpeta y configurar MySQL | Se inicia el JAR y conecta usando la guía | Pendiente |

Para evidenciar concurrencia en el video puedes mostrar la salida real de la prueba. También verifica la respuesta de la interfaz directamente: la prueba de consola no demuestra por sí sola que la ventana sea receptiva.
