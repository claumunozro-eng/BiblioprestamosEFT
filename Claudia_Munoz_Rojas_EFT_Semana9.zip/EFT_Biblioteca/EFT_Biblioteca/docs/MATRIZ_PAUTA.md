# Correspondencia con la pauta de evaluación

Esta matriz muestra qué parte del proyecto responde a cada criterio. No asigna una nota ni sustituye la evaluación del docente.

| Criterio | Puntos | Implementación o evidencia | Pendiente personal |
|---|---|---|---|
| POO | 15 | Persona y Usuario abstractas, subclases, Entidad y CrudDAO, permisos polimórficos | Comprender y explicar el diseño |
| MVC DAO Singleton | 15 | Paquetes view/controller/model/dao/service/config | Mostrar estructura en IntelliJ |
| Concurrencia y sincronización | 15 | SwingWorker, synchronized, transacciones y stock condicionado | Ejecutar prueba MySQL y comprobar interfaz |
| CRUD | 15 | Cuatro pantallas administrativas con persistencia; cinco DAO | Completar pruebas CRUD |
| Interfaz JFrame | 15 | Acceso, navegación por pestañas, gestión, circulación y reportes | Inspeccionar y demostrar la interfaz real |
| JDBC Singleton | 10 | DatabaseConnection, Connector/J, excepciones y consultas parametrizadas | Configurar servidor y verificar conexión |
| Video | 10 | Guion de cuatro minutos incluido | Grabar en Kaltura, incluir IDE y rostro |
| GitHub | 5 | Estructura, README, scripts, ejecutable y exclusión de claves locales | Publicar repositorio público y commits reales |

Los roles se verifican también en el servicio. La sincronización Java cubre hilos del mismo proceso; la operación SQL condicionada y el bloqueo de filas protegen las operaciones entre instancias. Las consultas se ejecutan en trabajadores para que esperar el monitor de la conexión no bloquee el hilo de Swing.
