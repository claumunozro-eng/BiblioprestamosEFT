# EFT de Desarrollo Orientado a Objetos II

Sistema de biblioteca escolar Java con interfaz Swing JFrame y persistencia MySQL JDBC. Incluye autenticación, roles, catálogo, CRUD de libros, estudiantes, categorías y usuarios, circulación y tres reportes. Los estudiantes consultan el catálogo, solicitan préstamos y devuelven únicamente sus propios préstamos. El bibliotecario administra el sistema.

**Empieza por [GUIA_IMPLEMENTACION_Y_ENTREGA.md](GUIA_IMPLEMENTACION_Y_ENTREGA.md).** Contiene el orden de instalación, los scripts, cuentas de prueba, pruebas manuales y entrega en AVA. El JAR está en `dist/biblioteca.jar`; requiere Java 17 o posterior y MySQL configurado. La aplicación no incorpora un servidor MySQL ni una copia de tu instalación local.

## Estructura

```text
src/main/java/cl/eft/biblioteca/
  model/       Entidades, Persona abstracta y permisos polimórficos
  view/        LoginView y MainView basadas en JFrame
  controller/  Eventos y SwingWorker
  service/     Permisos, circulación y transacciones
  dao/         CRUD y consultas JDBC parametrizadas
  config/      DatabaseConnection Singleton
  util/        PBKDF2 y conversión de claves de los datos oficiales
src/test/java/ Pruebas básicas y prueba real de concurrencia MySQL
sql/           Dos scripts oficiales y dos scripts complementarios
config/        Ejemplo de configuración sin claves personales
dist/          JAR ejecutable con Connector/J incluido
```

## Decisiones principales

* MVC: las vistas solo construyen controles; el controlador conecta eventos con el servicio y los DAO ejecutan SQL.
* DAO: interfaz `CrudDAO<T>` y base `JdbcDAO<T>`, con DAO concreto para las cinco entidades. La interfaz expone CRUD completo; las operaciones de préstamos se realizan a través del servicio de circulación para mantener el stock. No existe una pantalla que permita borrar arbitrariamente el historial.
* Singleton: `DatabaseConnection.getInstance()` devuelve una única instancia que administra una conexión JDBC. Todas las consultas y transacciones se serializan en su monitor para no compartir simultáneamente una conexión no segura entre hilos.
* Herencia y abstracción: `Persona` es abstracta; `Estudiante` y `Usuario` la extienden. `Usuario` es abstracta y tiene las subclases `Bibliotecario` y `UsuarioEstudiante`.
* Polimorfismo: el servicio y el controlador llaman `Usuario.puedeAdministrar()` sin decidir permisos por el nombre de la subclase. `descripcion()` permite describir las personas según su tipo.
* Concurrencia: el controlador usa `SwingWorker.doInBackground()` para acceso a datos y circulación; `done()` actualiza Swing en el hilo de eventos. El servicio declara `prestar`, `devolver` y operaciones de administración con `synchronized`.
* Consistencia: cada préstamo reduce stock e inserta su registro dentro de una transacción. Ese registro constituye también el historial del estudiante. `UPDATE ... WHERE stock>0` evita stock negativo entre procesos. Las devoluciones bloquean el préstamo con `FOR UPDATE`, impiden devolver dos veces y aumentan stock una sola vez. Ante un error se ejecuta rollback.
* Credenciales: las contraseñas se guardan con PBKDF2 y sal aleatoria. La herramienta `MigrarClaves` transforma explícitamente las claves de los scripts oficiales. Los roles de la base permanecen en minúsculas.
* Vencimiento: siete días por defecto, configurable entre 1 y 365. `fecha_devolucion` del script oficial se interpreta como fecha de vencimiento; `fecha_devolucion_real` conserva la fecha efectiva.

## Estado de verificación

Compilación con destino Java 17 y siete comprobaciones básicas ejecutadas. Connector/J se incluye en el JAR. No se ha verificado una sesión completa con MySQL ni la interfaz en pantalla en este entorno. La prueba de integración incluida y la lista de pruebas manuales deben ejecutarse en tu computador antes de entregar.

No se publicaron repositorios ni se subieron archivos al AVA. La grabación del video, la publicación y la entrega son pasos pendientes del estudiante.
