@echo off
cd /d "%~dp0"
java -jar dist\biblioteca.jar
if errorlevel 1 pause
