-- Ejecutar UNA VEZ, DESPUÉS de los dos scripts oficiales.
-- No elimina ni reemplaza sus registros. Requiere MySQL 8.0.16 o posterior.
USE biblioteca;
ALTER TABLE usuarios ENGINE=InnoDB;
ALTER TABLE estudiantes ENGINE=InnoDB;
ALTER TABLE categorias ENGINE=InnoDB;
ALTER TABLE libros ENGINE=InnoDB;
ALTER TABLE prestamos ENGINE=InnoDB;
ALTER TABLE usuarios MODIFY COLUMN `contraseña` VARCHAR(255) NOT NULL,
 ADD CONSTRAINT uq_usuario_correo UNIQUE(correo);
ALTER TABLE prestamos ADD COLUMN fecha_devolucion_real DATE NULL,
 ADD COLUMN dias_atraso INT NOT NULL DEFAULT 0,
 ADD CONSTRAINT chk_prestamo_fechas CHECK(fecha_devolucion>=fecha_prestamo),
 ADD CONSTRAINT chk_atraso CHECK(dias_atraso>=0);
ALTER TABLE libros ADD CONSTRAINT chk_stock CHECK(stock>=0);
-- En préstamos ya devueltos, la fecha real sigue NULL: el script oficial no la informa.
-- No se inventan atrasos históricos ni se modifica el stock inicial entregado.
