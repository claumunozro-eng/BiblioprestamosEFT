-- Opcional: ejecutar con una cuenta administradora MySQL.
-- Reemplaza esta contraseña y usa la misma en config/database.properties.
CREATE USER IF NOT EXISTS 'biblioteca_app'@'localhost' IDENTIFIED BY 'CAMBIAR_PASSWORD_LOCAL';
GRANT SELECT,INSERT,UPDATE,DELETE ON biblioteca.* TO 'biblioteca_app'@'localhost';
