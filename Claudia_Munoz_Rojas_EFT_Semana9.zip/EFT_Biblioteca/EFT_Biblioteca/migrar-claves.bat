@echo off
cd /d "%~dp0"
java -cp dist\biblioteca.jar cl.eft.biblioteca.util.MigrarClaves
if errorlevel 1 pause
